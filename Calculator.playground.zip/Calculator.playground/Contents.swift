import UIKit
// ADD
var number1 = 2
var number2 = 3
print("Your answer is : \(number1 + number2)")

//SUBTRACT
var number3 = 4
var number4 = 8
print("Your answer is: \(number4 - number3)")


print("The numbers mulitplied together are: \(number1 * number3)")

print("The numbers divided together are: \(number2 / number4)")
